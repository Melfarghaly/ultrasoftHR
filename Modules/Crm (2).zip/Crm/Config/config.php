<?php

return [
    'name' => 'Crm',
    'module_version' => "1.5",
    'pid' => 7
];
