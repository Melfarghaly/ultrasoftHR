<?php

Route::group(['middleware' => ['web', 'authh', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'], 'prefix' => 'project', 'namespace' => 'Modules\Project\Http\Controllers'], function () {
    Route::put('project/{id}/post-status', 'ProjectController@postProjectStatus');
    Route::put('project-settings', 'ProjectController@postSettings');
    // Show the form to create a new project
    Route::get('project/create', 'ProjectController@create')->name('project.create');
    
    // Store a new project in the database
    Route::post('project', 'ProjectController@store')->name('project.store');
    
    // Show a specific project
    Route::get('project/{id}', 'ProjectController@show')->name('project.show');
    
    // Show the form to edit an existing project
    Route::get('project/{id}/edit', 'ProjectController@edit')->name('project.edit');
    
    // Update an existing project in the database
    Route::put('project/{id}', 'ProjectController@update')->name('project.update');
    
    // Delete an existing project
    Route::delete('project/{id}', 'ProjectController@destroy')->name('project.destroy');
    
    // List all projects
    Route::get('project', 'ProjectController@index')->name('project.index');

    Route::resource('project-task', 'TaskController');
    // Separate routes for 'project-task' resource
    Route::get('project-task', 'TaskController@index')->name('project-task.index');
    Route::get('project-task/create', 'TaskController@create')->name('project-task.create');
    Route::post('project-task', 'TaskController@store')->name('project-task.store');
    Route::get('project-task/{id}', 'TaskController@show')->name('project-task.show');
    Route::get('project-task/{id}/edit', 'TaskController@edit')->name('project-task.edit');
    Route::put('project-task/{id}', 'TaskController@update')->name('project-task.update');
    Route::delete('project-task/{id}', 'TaskController@destroy')->name('project-task.destroy');

    Route::get('project-task-get-status', 'TaskController@getTaskStatus');
    Route::put('project-task/{id}/post-status', 'TaskController@postTaskStatus');
    Route::put('project-task/{id}/post-description', 'TaskController@postTaskDescription');
    Route::resource('project-task-comment', 'TaskCommentController');
    Route::post('post-media-dropzone-upload', 'TaskCommentController@postMedia');
    Route::resource('project-task-time-logs', 'ProjectTimeLogController');
    Route::resource('activities', 'ActivityController')->only(['index']);
    Route::get('project-invoice-tax-report', 'InvoiceController@getProjectInvoiceTaxReport');
    Route::resource('invoice', 'InvoiceController');
    Route::get('project-employee-timelog-reports', 'ReportController@getEmployeeTimeLogReport');
    Route::get('project-timelog-reports', 'ReportController@getProjectTimeLogReport');
    Route::get('project-reports', 'ReportController@index');

    Route::get('/install', 'InstallController@index');
    Route::post('/install', 'InstallController@install');
    Route::get('/install/uninstall', 'InstallController@uninstall'); 
    Route::get('/install/update', 'InstallController@update');
    
    
    // InvoiceController
    Route::get('/invoice', 'InvoiceController@index')->name('invoice.index');
    Route::post('/invoice', 'InvoiceController@store')->name('invoice.store');
    Route::get('/invoice/{id}/edit', 'InvoiceController@edit')->name('invoice.edit');
    Route::put('/invoice/{id}', 'InvoiceController@update')->name('invoice.update');
    Route::delete('/invoice/{id}', 'InvoiceController@destroy')->name('invoice.destroy');
    
    // TaskController
    Route::resource('project-task', 'TaskController')->except(['show']);
    Route::get('project-task/{id}/show', 'TaskController@show')->name('project-task.show');
    
    // ProjectTimeLogController
    Route::resource('project-task-time-logs', 'ProjectTimeLogController')->except(['show']);
    Route::get('project-task-time-logs/{id}/show', 'ProjectTimeLogController@show')->name('project-task-time-logs.show');
    
    // TaskCommentController
    Route::resource('project-task-comment', 'TaskCommentController')->except(['show']);
    Route::get('project-task-comment/{id}/show', 'TaskCommentController@show')->name('project-task-comment.show');
    
    // ActivityController
    Route::resource('activities', 'ActivityController')->only(['index']);

// Routes for 'project-task-comment' resource
    Route::resource('project-task-comment', 'TaskCommentController')->only(['index', 'create']);
    Route::post('project-task-comment', 'TaskCommentController@store')->name('project-task-comment.store');
    Route::get('project-task-comment/{id}/edit', 'TaskCommentController@edit')->name('project-task-comment.edit');
    Route::put('project-task-comment/{id}', 'TaskCommentController@update')->name('project-task-comment.update');
    Route::delete('project-task-comment/{id}', 'TaskCommentController@destroy')->name('project-task-comment.destroy');
    
    // Routes for 'project-task-time-logs' resource
    Route::resource('project-task-time-logs', 'ProjectTimeLogController')->only(['index', 'create']);
    Route::post('project-task-time-logs', 'ProjectTimeLogController@store')->name('project-task-time-logs.store');
    Route::get('project-task-time-logs/{id}/edit', 'ProjectTimeLogController@edit')->name('project-task-time-logs.edit');
    Route::put('project-task-time-logs/{id}', 'ProjectTimeLogController@update')->name('project-task-time-logs.update');
    Route::delete('project-task-time-logs/{id}', 'ProjectTimeLogController@destroy')->name('project-task-time-logs.destroy');
    
    // Routes for 'activities' resource with only 'index' action
Route::get('activities', 'ActivityController@index')->name('activities.index');

// Routes for 'invoice' resource
Route::get('invoice', 'InvoiceController@index')->name('invoice.index');
Route::get('invoice/create', 'InvoiceController@create')->name('invoice.create');
Route::post('invoice', 'InvoiceController@store')->name('invoice.store');
Route::get('invoice/{id}', 'InvoiceController@edit')->name('invoice.edit');
Route::get('invoice/{id}', 'InvoiceController@show')->name('invoice.show');

Route::put('invoice/{id}', 'InvoiceController@update')->name('invoice.update');
Route::delete('invoice/{id}', 'InvoiceController@destroy')->name('invoice.destroy');

// Routes for 'project-task' resource with all actions except 'show'
Route::get('project-task', 'TaskController@index')->name('project-task.index');
Route::get('project-task/create', 'TaskController@create')->name('project-task.create');
Route::post('project-task', 'TaskController@store')->name('project-task.store');
Route::get('project-task/{id}/edit', 'TaskController@edit')->name('project-task.edit');
Route::put('project-task/{id}', 'TaskController@update')->name('project-task.update');
Route::delete('project-task/{id}', 'TaskController@destroy')->name('project-task.destroy');




});

